SELECT stusps, name As state, ST_Transform(the_geom,2163)::geometry(MULTIPOLYGON,2163) As geom
INTO states_az_nm_tz
	FROM state
	WHERE stusps IN('AZ', 'NM', 'TX');
