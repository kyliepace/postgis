statessp020_nt00032.tar.gz: http://dds.cr.usgs.gov/pub/data/nationalatlas/statesp020_nt00032.tar.gz.
(Note nationalatlas will be seizing service in Sept 2014)

bayarea_bridges.zip -- downloaded 2006 from sanfrancisco share http://gispub02.sfgov.org/website/sfshare/catalog/bayarea_bridges.zip. (no longer available on web)